function disTime(){
    var date = new Date();
    var hour = date.getHours(); // 0 - 23
    var min = date.getMinutes(); // 0 - 59
    var sec = date.getSeconds(); // 0 - 59




    if (hour < 10) { //If the intger for h is less than 10, or true, add a zero before the integer. If false, it is just the hour. 
        hour = "0" + hour
    } else {
        hour = hour
    }

    if (min < 10) {
        min = "0" + min
    } else {
        min = min
    }

    if (sec < 10) {
        sec = "0" + sec
    } else {
        sec = sec
    }
    
    var time = hour + ":" + min + ":" + sec + " "; //creates the var 'time' and combines other variables
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;
    
    setTimeout(disTime, 1000);
    
}

disTime();